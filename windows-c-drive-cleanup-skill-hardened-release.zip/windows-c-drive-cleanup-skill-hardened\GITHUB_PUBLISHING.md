# GitHub Publishing Notes

Suggested repository name:

```text
windows-c-drive-cleanup-skill-hardened
```

Suggested short description:

```text
A hardened Codex skill for privacy-first Windows C: drive analysis and cautious cleanup guidance.
```

Suggested topics:

```text
codex-skill
windows
disk-cleanup
powershell
privacy
system-safety
```

Suggested first release title:

```text
v1.0.0 - Hardened Windows C Drive Cleanup Skill
```

Suggested first release notes:

```text
Initial hardened release of the Windows C Drive Cleanup Skill.

This version focuses on read-only C: drive analysis, risk classification, and quarantine-only Windows Installer MSP review. It does not delete files under C:\Windows, including original Windows Installer cache files.
```
